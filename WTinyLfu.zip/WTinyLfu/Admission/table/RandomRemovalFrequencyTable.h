//
// Created by mahmo on 8/17/2020.
//

#ifndef WTINYLFU_RANDOMREMOVALFREQUENCYTABLE_H
#define WTINYLFU_RANDOMREMOVALFREQUENCYTABLE_H


#include <cstdio>      /* printf, NULL */
#include <cstdlib>
#include "../Frequency.h"
#include "../../BasicSettings.h"
#include <vector>
#include <list>
#include <map>
#include <unordered_map>
#include <ctime>


class RandomRemovalFrequencyTable : public Frequency{
private:
    /** sum of total items */
    int maxSum;
    /** total sum of stored items **/
    int currSum;
    /** controls both the max count and how many items are remembered (the sum) */
    int sampleFactor = 8;
    /** used to dropped items at random */
    float random;
    /** a place holder for TinyTable */
    std::unordered_map<long, int>* table;
public:
    RandomRemovalFrequencyTable(BasicSettings* settings) {
      srand(time(NULL));
      maxSum = sampleFactor * settings->getMaximumSize();
      srand(settings->getRandomSeed());
      random = (float)rand();
      table = new std::unordered_map<long,int> (maxSum);
    }

    ~RandomRemovalFrequencyTable(){
      delete table;
    }

    int frequency(long e) override {
      return table->find(e)->second;
    }


    void increment(long e) override {
      // there is a problem here mahmod mahmo
      int value = table->find(e)->second;
      // if the value is big enough there is no point in dropping a value so we just quit
      if (value > sampleFactor) {
        return;
      }
    }
};


#endif //WTINYLFU_RANDOMREMOVALFREQUENCYTABLE_H
