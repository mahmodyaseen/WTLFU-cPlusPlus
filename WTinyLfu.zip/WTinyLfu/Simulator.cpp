////
//// Created by mahmo on 8/10/2020.
////
//
//#include <fstream>
//#include <string>
//#include <regex>
//#include <iostream>
//#include "request.h"
//
//using namespace std;
//
//int main (int argc, char* argv[])
//{
////  argc = 5;
////  argv = {"webcachesim"," test.tr"," LRU ","1000"};
//  // output help if insufficient params
//  if(argc < 4) {
//    std::cerr << "webcachesim traceFile cacheType cacheSizeBytes [cacheParams]" << endl;
//    return 1;
//  }
//
//  // trace properties
//  const char* path = argv[1];
//
//  // create cache
//  const string cacheType = argv[2];
//  unique_ptr<Cache> webcache = Cache::create_unique(cacheType);
//  if(webcache == nullptr)
//    return 1;
//
//  // configure cache size
//  const uint64_t cache_size  = std::stoull(argv[3]);
//  webcache->setSize(cache_size);
//
//  // parse cache parameters
//  regex opexp ("(.*)=(.*)");
//  cmatch opmatch;
//  string paramSummary;
//  for(int i=4; i<argc; i++) {
//    regex_match (argv[i],opmatch,opexp);
//    if(opmatch.size()!=3) {
//      cerr << "each cacheParam needs to be in form name=value" << endl;
//      return 1;
//    }
//    webcache->setPar(opmatch[1], opmatch[2]);
//    paramSummary += opmatch[2];
//  }
//
//  ifstream infile;
//  long long reqs = 0, hits = 0;
//  long long t, id, size;
//
//  cerr << "running..." << endl;
//
//  infile.open(path);
//  SimpleRequest* req = new SimpleRequest(0, 0);
//  while (infile >> t >> id >> size)
//  {
//    reqs++;
//
//    req->reinit(id,size);
//    if(webcache->lookup(req)) {
//      hits++;
//    } else {
//      webcache->admit(req);
//    }
//  }
//
//  delete req;
//
//  infile.close();
//  cout << cacheType << " " << cache_size << " " << paramSummary << " "
//       << reqs << " " << hits << " "
//       << double(hits)/reqs << endl;
//
//  return 0;
//
//}
//

#include <fstream>
#include <string>
#include <regex>
#include <iostream>
#include "policy/PolicyStats.h"
#include "policy/AccessEvent.h"
//#include <list>
#include "policy/sketch/WindowTinyLfuPolicy.h"
#include "policy/sketch/climbing/HillClimberWindowTinyLfuPolicy.h"

using namespace std;

int main(int argc,char* argv[]){
  const char* path = argv[1];
  const char* name = argv[2];


  ifstream infile;
  long  reqs = 0, hits = 0;
  long  t, id, size;

  cout << "running..." << endl;

  infile.open(path);

  BasicSettings *settings= new BasicSettings();
  list<AccessEvent> *events = new list<AccessEvent>;
  while (infile >> id  )
  {
    AccessEvent event(id);
    reqs++;
    events->push_back(event);
//    req->reinit(id,size);
////    if(webcache->lookup(req)) {
////      hits++;
////    } else {
////      webcache->admit(req);
////    }
  }
  WindowTinyLFUPolicy policyNew(0.99 ,settings);
//  HillClimberWindowTinyLfuPolicy policyNew(0.80 , settings);

  for (list<AccessEvent>::iterator it=events->begin(); it != events->end(); ++it)
    policyNew.record(it->getKey());

//  policyNew.finished();

  policyStats* policystats = policyNew.stats();

  infile.close();
  cout << policystats->getName() << " " << policystats->hitRate() << " sex " << policystats->getEvictionCount()<<endl;
  cout << policystats->getHitCount() << " sex " << policystats->getMissCount()<< endl;
  return 0;
}